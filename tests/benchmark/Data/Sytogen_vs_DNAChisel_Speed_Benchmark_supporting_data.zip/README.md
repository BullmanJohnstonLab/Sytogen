# Sytogen vs. DNA Chisel — Speed & Scalability Benchmark: Supporting Data

Companion data to *Sytogen vs. DNA Chisel — Speed, Scalability, and Editing Efficiency* (Sections 2–3).

## Constructs

| File | Contents |
|---|---|
| `construct_manifest.json` | Coordinates for every segment (promoter, RBS, each gene, origin, backbone padding) and the list of deliberately-inserted RM motifs, for all four constructs |
| `small_1.5kb.gb`, `medium_4kb.gb`, `large_10kb.gb`, `xlarge_20kb.gb` | Full annotated GenBank records (promoter/RBS/CDS×N/rep_origin features) used as input to both tools |
| `motif_table.csv` | The 8-enzyme RM motif table (EcoRI, BamHI, HindIII, BsaI, BsmBI, NotI, XhoI, SalI) supplied to both tools for all runs |
| `codon_usage_table.csv` | Synthetic codon-usage table supplied to Sytogen |

## Sytogen results

| File | Contents |
|---|---|
| `sytogen_timing_and_summary.json` | Per-construct: wall-clock time, full run summary (motifs_input/resolved/unresolved, edits_applied, new_motifs_introduced), and GC content before/after |

## DNA Chisel results

| File | Contents |
|---|---|
| `dnachisel_unprotected_timing.json` | Timing for all 4 sizes with RM-avoidance + reading-frame constraints only (no AvoidChanges) |
| `dnachisel_1.5kb_4kb_protected_timing.json` | Timing for the 1.5 kb and 4 kb constructs with full protection (AvoidChanges on promoter/RBS/origin added) |
| `dnachisel_10kb_protected_aborted.json` | The 10 kb protected run — records the NoSolutionError message and elapsed time to failure; no output sequence exists for this run |
| `dnachisel_20kb_protected_timing.json` | Timing for the 20 kb construct with full protection |
| `dnachisel_edit_and_gc_summary.json` | Edit counts and GC content before/after for the protected runs that completed (1.5 kb, 4 kb, 20 kb) |

## Reproducing

```python
# Sytogen
from sytogen.scripts.sytogen_runner import run_sytogen_pipeline
result = run_sytogen_pipeline(seq_record, codon_df, motif_df, params={"topology": "circular"})

# DNA Chisel
from dnachisel import AvoidPattern, EnforceTranslation, AvoidChanges, Location, CircularDnaOptimizationProblem
problem = CircularDnaOptimizationProblem(sequence=seq, constraints=[...])
problem.resolve_constraints()
```

All timings were taken with `time.perf_counter()` wrapped tightly around the single `resolve_constraints()` / `run_sytogen_pipeline()` call, sequentially on one machine with no other load. See the report's Section 6 for limitations (single-run, single-machine — no repeated trials or confidence intervals).
