"""
Reimplementation of the algorithm described in:
Condon, A. and Thachuk, C. "Efficient codon optimization with motif engineering."
Journal of Discrete Algorithms 16 (2012): 104-112.

IMPORTANT: This is an independent Python reimplementation based on the published
algorithm description (dynamic programming over codon designs, CAI objective,
hard forbidden-motif avoidance, optional desired-motif reward). It is NOT the
original C++ tool ("codon-optimizer") published by the authors at
https://www.cs.ubc.ca/labs/algorithms/Projects/codon-optimizer/ , which could not
be downloaded/built in this environment (see accompanying notes). Results here
characterize the published algorithm's behavior, not the original binary's
implementation-specific details (e.g. exact tie-breaking, I/O handling, or any
bugs/deviations the original binary might have).

Algorithm summary (as implemented here):
- Input: an amino acid sequence A, a codon usage table (-> per-codon relative
  adaptiveness weights w(codon), Sharp & Li 1987 CAI weights), a set of forbidden
  motifs (hard constraint: none may appear anywhere in the final nucleotide
  sequence, including across codon boundaries), and optionally a set of desired
  motifs to reward.
- Output: the amino-acid-preserving nucleotide sequence that maximizes CAI
  (equivalently, maximizes the sum of log-weights of the chosen codons) subject
  to the hard forbidden-motif constraint, found by dynamic programming with a
  guarantee of global optimality -- or a report that no valid sequence exists.

Implementation note on state space: the original paper's DP indexes state by the
last k codons (k = ceil(max_motif_length / 3)), bounding the state space by the
codon-degeneracy of the genetic code. This reimplementation instead keys DP state
by the last (L-1) nucleotides directly (L = max forbidden/desired motif length),
which is simpler to implement correctly and is provably equivalent in terms of
the optimum found, at the cost of a larger (but still polynomial, and for our
short motif lengths entirely tractable) state space. Both formulations find the
same true optimum; they differ only in computational efficiency, not in the
answer produced.
"""

import itertools
import math
import time


STANDARD_CODON_TABLE = {
    'TTT':'F','TTC':'F','TTA':'L','TTG':'L',
    'CTT':'L','CTC':'L','CTA':'L','CTG':'L',
    'ATT':'I','ATC':'I','ATA':'I','ATG':'M',
    'GTT':'V','GTC':'V','GTA':'V','GTG':'V',
    'TCT':'S','TCC':'S','TCA':'S','TCG':'S',
    'CCT':'P','CCC':'P','CCA':'P','CCG':'P',
    'ACT':'T','ACC':'T','ACA':'T','ACG':'T',
    'GCT':'A','GCC':'A','GCA':'A','GCG':'A',
    'TAT':'Y','TAC':'Y','TAA':'*','TAG':'*',
    'CAT':'H','CAC':'H','CAA':'Q','CAG':'Q',
    'AAT':'N','AAC':'N','AAA':'K','AAG':'K',
    'GAT':'D','GAC':'D','GAA':'E','GAG':'E',
    'TGT':'C','TGC':'C','TGA':'*','TGG':'W',
    'CGT':'R','CGC':'R','CGA':'R','CGG':'R',
    'AGT':'S','AGC':'S','AGA':'R','AGG':'R',
    'GGT':'G','GGC':'G','GGA':'G','GGG':'G',
}

AA_TO_CODONS = {}
for _codon, _aa in STANDARD_CODON_TABLE.items():
    AA_TO_CODONS.setdefault(_aa, []).append(_codon)


def translate(nt_seq):
    return "".join(STANDARD_CODON_TABLE[nt_seq[i:i+3]] for i in range(0, len(nt_seq), 3))


def build_cai_weights(codon_fraction):
    """Sharp & Li (1987) relative adaptiveness: w(codon) = freq(codon) / max freq
    among synonymous codons for the same amino acid."""
    weights = {}
    for aa, codons in AA_TO_CODONS.items():
        freqs = [codon_fraction.get(c, 1e-9) for c in codons]
        max_freq = max(freqs) if freqs else 1e-9
        for c in codons:
            weights[c] = codon_fraction.get(c, 1e-9) / max_freq
    return weights


def contains_any_motif(window, motifs):
    for m in motifs:
        if m in window:
            return True
    return False


def optimize(protein_seq, codon_weights, forbidden_motifs, desired_motifs=None,
             desired_bonus=0.0):
    """
    Returns (best_nt_sequence, log_score, stats, feasible: bool).

    protein_seq: amino acid string, no stop codon appended (added automatically
                 if present in translation table use is not required here).
    codon_weights: dict codon -> CAI weight (0,1]
    forbidden_motifs: list of nucleotide strings, none may appear anywhere in
                       the output (checked across codon boundaries).
    desired_motifs: optional list of nucleotide strings to reward (adds
                     desired_bonus to the log-score each time one is newly
                     completed at the current position).
    """
    desired_motifs = desired_motifs or []
    all_motifs = forbidden_motifs + desired_motifs
    max_len = max((len(m) for m in all_motifs), default=1)
    suffix_len = max_len - 1  # nucleotides of context needed to detect a motif ending here

    return _reconstruct(protein_seq, codon_weights, forbidden_motifs, desired_motifs,
                         desired_bonus, suffix_len, max_len)


def _reconstruct(protein_seq, codon_weights, forbidden_motifs, desired_motifs,
                  desired_bonus, suffix_len, max_len):
    # Full DP keeping backpointers for traceback.
    # dp[state] = (score, list_of_codons_so_far) -- list kept only at final step
    # to control memory we keep parent chain via dict of dicts per step.
    layers = [{"": (0.0, None, None)}]  # layers[i] = state -> (score, prev_state, codon)
    for i, aa in enumerate(protein_seq):
        prev_layer = layers[-1]
        candidates = AA_TO_CODONS[aa]
        new_layer = {}
        for state, (score, _p, _c) in prev_layer.items():
            for codon in candidates:
                w = codon_weights.get(codon, 1e-9)
                if w <= 0:
                    continue
                extended = state + codon
                check_region = extended[-(suffix_len + 3):] if suffix_len + 3 <= len(extended) else extended
                forbidden_hit = False
                bonus = 0.0
                for L in range(1, max_len + 1):
                    if len(check_region) < L:
                        continue
                    for end in range(len(check_region) - 2, len(check_region) + 1):
                        start = end - L
                        if start < 0:
                            continue
                        window = check_region[start:end]
                        if window in forbidden_motifs:
                            forbidden_hit = True
                        if window in desired_motifs:
                            bonus += desired_bonus
                if forbidden_hit:
                    continue
                new_state = extended[-suffix_len:] if suffix_len > 0 else ""
                new_score = score + math.log(w) + bonus
                if new_state not in new_layer or new_score > new_layer[new_state][0]:
                    new_layer[new_state] = (new_score, state, codon)
        if not new_layer:
            return None, None, {"feasible": False, "fail_position": i}, False
        layers.append(new_layer)

    final_layer = layers[-1]
    best_state = max(final_layer, key=lambda s: final_layer[s][0])
    best_score = final_layer[best_state][0]

    # traceback
    codons = []
    state = best_state
    for i in range(len(protein_seq), 0, -1):
        score, prev_state, codon = layers[i][state]
        codons.append(codon)
        state = prev_state
    codons.reverse()
    nt_seq = "".join(codons)

    stats = {
        "feasible": True,
        "log_score": best_score,
        "cai_geometric_mean": math.exp(best_score / len(protein_seq)),
        "n_codons": len(protein_seq),
    }
    return nt_seq, best_score, stats, True


if __name__ == "__main__":
    # smoke test
    import sys
    print("Module loaded OK. AA_TO_CODONS entries:", len(AA_TO_CODONS))
