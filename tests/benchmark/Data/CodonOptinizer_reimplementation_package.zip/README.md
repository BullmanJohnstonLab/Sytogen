# Condon & Thachuk (2012) Algorithm Reimplementation - Supporting Files

This is NOT the original "codon-optimizer" C++ tool from
https://www.cs.ubc.ca/labs/algorithms/Projects/codon-optimizer/ - that tool could
not be downloaded/built in the test environment (its host, cs.ubc.ca, is outside
the available network egress allowlist, and no GitHub mirror exists).

Instead, this is an independent Python reimplementation of the dynamic-programming
algorithm described in the published paper (Condon & Thachuk, "Efficient codon
optimization with motif engineering," Journal of Discrete Algorithms 16 (2012):
104-112), built directly from the paper's algorithm description.

## Files

- `condon_thachuk_dp.py` - the reimplementation. See the module docstring for a
  full description of the algorithm and an explicit note on where this
  implementation's state-space construction differs from the paper's (both are
  provably optimal; they differ only in computational efficiency, not in the
  answer produced).
- `condon_thachuk_cds_result.json` - result of running the reimplementation on
  the exact 270 bp CDS used to test SyToGen and DNA Chisel in the
  "Protected-Site Safety" benchmark report, with the same 3-motif forbidden list
  (EcoRI/BsaI/BsmBI). Directly comparable to those tools' results on edit count
  and motif removal (not on speed - see caveat below).
- `condon_thachuk_speed_results.json` - results of running the reimplementation
  against the CDS regions of the four gene-dense constructs (1.5-20 kb) used in
  the "Speed, Scalability, and Editing Efficiency" report. Edit counts are
  meaningful; the `total_time_sec` fields are NOT comparable to that report's
  SyToGen/DNA Chisel timings (see caveat below).

## What is and isn't trustworthy here

**Trustworthy (algorithm-inherent, implementation-independent):** edit counts,
which motifs were removed, and the CAI achieved. This algorithm is a
provably-optimal dynamic program over a well-defined objective (maximize CAI
subject to zero forbidden motifs) - any correct implementation, including the
original C++ binary, must converge on the same score given the same inputs.
Before running on real data, this reimplementation was checked against hand-
verifiable smoke tests: a forced-conflict case (best codon creates a forbidden
motif, DP must pick the second-best), an infeasibility case (all synonymous
codons for an amino acid forbidden), and a motif spanning multiple codon
boundaries. All passed.

**Not trustworthy (implementation-dependent):** wall-clock timing. This is
unoptimized Python, and it uses a nucleotide-suffix DP state space rather than
the paper's own codon-indexed formulation (smaller, bounded by codon
degeneracy rather than by motif length) - both find the same optimum, but the
paper's construction is more time/space-efficient. The original C++ binary
would very plausibly be substantially faster than what was measured here. No
timing comparison to SyToGen or DNA Chisel should be drawn from these files.

## Key finding

On the identical CDS where SyToGen and DNA Chisel each made exactly 1 minimal
edit to remove a restriction site, this algorithm made 2 edits and drove CAI to
1.0 - the extra edit was unrelated to motif removal, a byproduct of the
algorithm's actual objective (full CAI optimization) rather than minimizing
changes to the input sequence. This pattern held at scale: 28-380 edits across
the four larger test constructs, versus SyToGen's near-1-edit-per-resolved-site
pattern on the same constructs (see the Speed benchmark report).
