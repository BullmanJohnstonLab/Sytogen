# Sytogen vs. DNA Chisel — Supporting Data Files

Companion data to *Sytogen vs. DNA Chisel — Protected-Site Safety Benchmark* (Section 2.1 and Section 3).
Sequence coordinates throughout are 0-based, half-open, matching the report and the underlying Python code.

## Input / construct definition

| File | Contents |
|---|---|
| `construct_coordinates.json` | Start/end coordinates for every named segment of the 717 bp synthetic construct (promoter parts, RBS, CDS, ori_core, backbone segments) |
| `construct.gb` | The full GenBank record used as input: sequence + `promoter`, `RBS`, `CDS`, `rep_origin` features, as fed to Sytogen |
| `input_sequence.txt` | Raw 717 bp sequence, no annotations (same sequence as in `construct.gb`) |
| `motif_table.csv` | The 3-row RM motif table given to both tools: EcoRI (GAATTC), BsaI (GGTCTC), BsmBI (CGTCTC). No coordinates supplied — each tool had to locate all occurrences itself |
| `codon_usage_table.csv` | Synthetic *E. coli*-like codon usage table (codon, fraction) supplied to Sytogen for synonymous-codon scoring |

## Sytogen output

| File | Contents |
|---|---|
| `sytogen_decision_matrix_full.csv` | The complete 53-row decision matrix — every candidate edit Sytogen scored for every motif, winners and losers alike, with `reasoning`, `usage_score`, `gc_preserving`, `chosen`, and (for blocked motifs) `skip_reason` |
| `sytogen_key_rows_summary.csv` | Just the chosen/blocked rows from the matrix above (4 rows — one per motif) |
| `sytogen_run_summary.json` | Run-level counters: `motifs_input`, `motifs_resolved`, `motifs_unresolved`, `edits_applied`, `new_motifs_introduced`, etc. |
| `sytogen_output_sequence.fasta` | Final edited sequence Sytogen returned |

## DNA Chisel output

| File | Contents |
|---|---|
| `dnachisel_naive_output_sequence.txt` | Final sequence from the *naive* configuration (RM-pattern avoidance + CDS translation only, no `AvoidChanges` on promoter/RBS) — this is the run where the promoter and RBS were mutated |
| `dnachisel_per_constraint_log.json` | Per-constraint resolution log from the *properly configured* run (all `AvoidChanges` added): for each constraint, whether `resolve_constraint()` raised an exception, and separately, whether that constraint actually passed on final evaluation — plus the final sequence and which positions changed |
| `dnachisel_per_constraint_log.csv` | Same per-constraint log, flattened to CSV (constraint, call result, final pass/fail, final message) |

Note: the standard `problem.resolve_constraints()` entry point on the properly-configured constraint set raises `NoSolutionError` on the BsaI/RBS constraint and returns no output sequence at all — that failure is documented in the report (Section 3.3) but has no corresponding file here, since no sequence was produced. The per-constraint log above is what was used to inspect the run's actual behavior after that.

## Reproducing

All coordinates and tables above are the literal inputs to the two calls documented in the report's Appendix A:

```python
# Sytogen
from sytogen.scripts.sytogen_runner import run_sytogen_pipeline
result = run_sytogen_pipeline(seq_record, codon_df, motif_df, params={"topology": "circular"})

# DNA Chisel
from dnachisel import AvoidPattern, EnforceTranslation, AvoidChanges, Location, CircularDnaOptimizationProblem
problem = CircularDnaOptimizationProblem(sequence=seq, constraints=[...])
problem.resolve_constraints()
```
