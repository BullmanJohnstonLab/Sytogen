# MEME Suite (FIMO) Empirical Test - Supporting Data

Unlike the Geneious Prime/Benchling/CodonOptinizer rows in the companion
spreadsheet, this is a real empirical test of the actual tool: `pymemesuite`
(https://pypi.org/project/pymemesuite/) provides Cython bindings around the
genuine vendored MEME Suite C source code, installed cleanly from a prebuilt
PyPI wheel. FIMO ("Find Individual Motif Occurrences") was run directly - this
is not a reimplementation.

## What MEME Suite actually is

A motif discovery and scanning toolkit (MEME, STREME, FIMO, MAST, Tomtom,
etc.), most commonly used to find and characterize motifs like transcription
factor binding sites. It has no sequence-editing capability of any kind -
FIMO reports where a motif occurs (with a statistical score, p-value, and
q-value); it cannot remove or modify anything. This makes it architecturally
different from every other tool in the comparison spreadsheet, which are all
sequence *design/editing* tools. The only meaningful axis to test here is
**detection accuracy**, not editing safety or speed.

## Files

- `fimo_adversarial_construct_results.json` - FIMO run against the exact
  717 bp adversarial construct from the "Protected-Site Safety" report (same
  3-motif set: EcoRI/BsaI/BsmBI), using a corrected per-motif threshold. All
  three planted sites were found at their exact coordinates.
- `fimo_speed_results_naive_shared_threshold.json` - FIMO run against the
  four gene-dense speed-test constructs (1.5-20kb) using FIMO's documented
  default threshold (1e-4) and a single relaxed threshold (0.001) shared
  across all 8 RM enzyme motifs. Demonstrates two real findings (see below).
- `fimo_speed_results_per_motif_threshold.json` - the same four constructs,
  this time with each motif's significance threshold individually tuned just
  above its own exact-match p-value ceiling. Every count matches ground-truth
  substring search exactly, confirming FIMO's core matching engine is correct
  once properly configured.

## Two real findings

**1. Short exact motifs are invisible at FIMO's own default threshold.**
The best-possible p-value for a perfect match to a k-mer against a uniform
background is 0.25^k. For a 6bp motif, that's 0.000244 - which is *worse*
(less significant) than FIMO's documented default threshold of 1e-4. Result:
7 of 8 common RM enzymes tested (all 6bp: EcoRI, BamHI, HindIII, BsaI, BsmBI,
XhoI, SalI) cannot register a hit at the default threshold no matter how
perfect the match. Confirmed empirically: 0 hits for all three 6bp motifs
scanned against the adversarial construct at threshold=1e-4, despite all
three being present and exact.

**2. A single relaxed threshold does not transfer cleanly across a mixed-
length motif panel.** Loosening the threshold enough to catch 6bp exact
matches (e.g. 0.001) is then loose enough to admit single-mismatch NEAR-
matches for longer motifs - confirmed with NotI (8bp): 26 hits reported at
threshold=0.001 vs. 4 true occurrences, because an 8bp motif retains enough
cumulative evidence after one mismatch to still look statistically
significant, while a 6bp motif with one mismatch does not. Only per-motif-
length-tuned thresholds gave clean, ground-truth-matching results.

## What this means practically

Once correctly configured (per-motif thresholds), FIMO's actual matching is
accurate - 100% agreement with ground-truth substring search across all 4
construct sizes and all 8 enzymes. But getting there requires understanding
and correcting for a threshold pitfall that a user relying on defaults, or a
single shared threshold across an enzyme panel with mixed recognition-site
lengths (very common - most bacterial RM systems mix 4, 6, and 8bp
specificities), would not obviously catch. This is a genuine usability gap
relative to the deterministic exact/IUPAC string matching used natively by
every editing tool in this comparison (SyToGen, DNA Chisel, Geneious,
Benchling, CodonOptinizer) - none of which have any p-value threshold to
tune in the first place, since they check literal sequence identity, not
statistical significance.

## Reproducing

```python
from pymemesuite.common import Alphabet, Array, Matrix, Motif, Background, Sequence
from pymemesuite.fimo import FIMO

alphabet = Alphabet.dna()
background = Background(alphabet, Array([0.25, 0.25, 0.25, 0.25]))

# Build a near-exact-match PSSM for a literal motif (see fimo_adversarial_construct_results.json
# generation script for the full build_exact_motif() helper)
motif = build_exact_motif("GAATTC", "EcoRI")

# IMPORTANT: threshold must be set per motif length, just above 0.25**len(motif),
# or short exact matches will be missed (see finding 1) and/or long motifs will
# admit near-match false positives (see finding 2).
fimo = FIMO(both_strands=True, threshold=0.25**len("GAATTC") * 1.05)
pattern = fimo.score_motif(motif, [Sequence(seq, name=b"my_sequence")], background)
```
